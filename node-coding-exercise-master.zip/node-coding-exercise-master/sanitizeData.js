const _ = require('lodash');

const KEY = 'key';
const VERSIONS = 'versions';
const OBJECTS = 'objects';
const FIELDS = 'fields';
const SCENES = 'scenes';
const VIEWS = 'views';

function removeDuplicatesByKey(list, key = KEY) {
  let existingKeys = [];
  return list.filter((item) => {
    if (existingKeys.includes(item[key])) {
      return false;
    } else {
      item[key] ? existingKeys.push(item[key]) : null;
      return item[key];
    }
  });
}

function sanitizeVersions(versions) {
  return versions.map((version) => {
    const sanitizedObjects = removeDuplicatesByKey(version[OBJECTS]);
    const sanitizedScenes = removeDuplicatesByKey(version[SCENES]);

    const sanitizedObjectsAndFields = sanitizedObjects.map((object) => {
      object[FIELDS] = removeDuplicatesByKey(object[FIELDS]);
      return object;
    });

    const sanitizedScenesAndViews = sanitizedScenes.map((scene) => {
      scene[VIEWS] = removeDuplicatesByKey(scene[VIEWS]);
      return scene;
    });

    version[OBJECTS] = sanitizedObjectsAndFields;
    version[SCENES] = sanitizedScenesAndViews;

    return version;
  });
}

function sanitizeData(data) {
  const sanitizedData = _.cloneDeep(data);

  try {
    sanitizedData[VERSIONS] = sanitizeVersions(sanitizedData[VERSIONS]);

    return sanitizedData;
  } catch (err) {
    throw new Error(`Data is not as expected`);
  }
}

module.exports.sanitizeData = sanitizeData;
