const readFile = require('./readFile');
const writeFile = require('./writeFile');
const { sanitizeData } = require('./sanitizeData');

const MOCK_APP_FILE_NAME = 'mock_application';
const CLEAN_APP_FILE_NAME = 'clean_application';

try {
  const jsonData = readFile.jsonFile(MOCK_APP_FILE_NAME);
  const sanitizedData = sanitizeData(jsonData);
  writeFile.jsonFile(sanitizedData, CLEAN_APP_FILE_NAME);
} catch (err) {
  console.error(`Proccess is not completed - ${err}`);
}
