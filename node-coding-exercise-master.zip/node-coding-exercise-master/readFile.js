const fs = require('fs');
const MOCK_APP_FILE_NAME = 'mock_application';

function jsonFile(fileName = MOCK_APP_FILE_NAME) {
  const contentFile = fs.readFileSync(`./${fileName}.json`, 'utf8');
  return JSON.parse(contentFile);
}

module.exports.jsonFile = jsonFile;
