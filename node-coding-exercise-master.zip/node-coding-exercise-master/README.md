## Launching local
`$ npm run start`

## Launching local dev
`$ npm run dev`

## Run tests
`$ npm run test`

## Output
The new JSON file is saved into `/output` folder.

## Important
I spent 2 hours on the exercise and this is what I got.

## Next steps
* Add more unit tests
* New JSON files could include a timestamp in their names in order to avoid rewriting
* Add constants file
* Add eslint
* Add pre-commit and pre-push hooks, using e.g. Husky

## Alternative design
Refactor `sanitizedData.js`.

`sanitizeData` function could analyze all attributes looking for any array as value and iterate on it in order to remove any item with a duplicated value in `"key"` attribute.

Pros:
* Recursion

Cons:
* It might clean arrays which actually it shouldn't