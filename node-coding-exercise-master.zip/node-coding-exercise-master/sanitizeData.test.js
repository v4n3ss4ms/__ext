const _ = require('lodash');
const { sanitizeData } = require('./sanitizeData');

const mockData = {
  att1_key: 'att1_value',
  versions: [
    {
      objects: [
        {
          key: 'object_2',
          fields: [
            {
              type: 'auto_increment',
              key: 'field_1',
            },
            {
              type: 'auto_increment',
              key: 'field_1',
            },
            {
              type: 'auto_increment',
              key: 'field_2',
            },
          ],
        },
        {
          key: 'object_3',
          fields: [
            {
              type: 'auto_increment',
              key: 'field_2',
            },
          ],
        },
        {
          key: 'object_2',
          fields: [
            {
              type: 'auto_increment',
              key: 'field_1',
            },
            {
              type: 'auto_increment',
              key: 'field_1',
            },
            {
              type: 'auto_increment',
              key: 'field_2',
            },
          ],
        },
      ],
      scenes: [
        {
          _id: '61',
          key: 'scene_1',
          views: [
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_5',
            },
          ],
        },
        {
          _id: '9a5',
          key: 'scene_2',
          views: [
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_5',
            },
          ],
        },
        {
          _id: '61',
          key: 'scene_1',
          views: [
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_5',
            },
          ],
        },
      ],
    },
  ],
};

const expectedData = {
  att1_key: 'att1_value',
  versions: [
    {
      objects: [
        {
          key: 'object_2',
          fields: [
            {
              type: 'auto_increment',
              key: 'field_1',
            },
            {
              type: 'auto_increment',
              key: 'field_2',
            },
          ],
        },
        {
          key: 'object_3',
          fields: [
            {
              type: 'auto_increment',
              key: 'field_2',
            },
          ],
        },
      ],
      scenes: [
        {
          _id: '61',
          key: 'scene_1',
          views: [
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_5',
            },
          ],
        },
        {
          _id: '9a5',
          key: 'scene_2',
          views: [
            {
              name: 'Menu',
              key: 'view_4',
            },
            {
              name: 'Menu',
              key: 'view_5',
            },
          ],
        },
      ],
    },
  ],
};
describe('Sanitize data', () => {
  it('sanitizes data', () => {
    const sanitizedData = sanitizeData(mockData);

    expect(_.isEqual(expectedData, sanitizedData)).toBe(true);
  });
});
