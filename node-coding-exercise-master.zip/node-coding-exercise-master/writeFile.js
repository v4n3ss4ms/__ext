const fs = require('fs');
const OUTPUT_DIR = 'output';
const CLEAN_APP_FILE_NAME = 'clean_application';

function jsonFile(content = {}, fileName = CLEAN_APP_FILE_NAME) {
  try {
    const fullPath = `./${OUTPUT_DIR}/${fileName}.json`;
    const stringifyContent = JSON.stringify(content);

    if (!fs.existsSync(OUTPUT_DIR)) {
      fs.mkdirSync(OUTPUT_DIR);
    }

    fs.writeFileSync(fullPath, stringifyContent, 'utf8');
    console.log(`File saved: ${fullPath}`);
  } catch (err) {
    console.error(`ERROR: File has not been written \n ${err}`);
  }
}

module.exports.jsonFile = jsonFile;
